package ru.geekbrains.classes.animals;

public interface Info {
    void showResults();
    void showTeam();
}
